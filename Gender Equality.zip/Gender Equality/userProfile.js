let formData = {}; 
const totalPrompts = document.querySelectorAll('.prompt').length;
let currentPromptIndex = 1;


// Next Button Function for the next question in the same section
    function showNextPrompt(nextPromptId) {
        var prompts = document.querySelectorAll('.prompt-box');
        var allFieldsValid = true;
    
        // Check if all required fields in the current section are filled
        var currentSection = document.querySelector('.prompt-box:not(.hidden)');
        var requiredFields = currentSection.querySelectorAll('[required]');
    
        for (var i = 0; i < requiredFields.length; i++) {
        if (!requiredFields[i].value) {
            allFieldsValid = false;
            alert('This is a mandatory field');

            requiredFields[i].classList.add('needs-attention');
        } else {
            // Remove the visual cue if the field is filled
            requiredFields[i].classList.remove('needs-attention');
        }
        }
    
        // If all required fields are valid, show the next prompt
        if (allFieldsValid) {
        for (var i = 0; i < prompts.length; i++) {
            prompts[i].classList.add('hidden');
        }
        if (nextPromptId) {
            document.getElementById(nextPromptId).classList.remove('hidden');
        }
        }
    }
  
    // Add an event listener for when the fields are filled
    document.addEventListener('input', function(event) {
    if (event.target.matches('[required]')) {
      // Check if the field is filled and remove the visual cue
      if (event.target.value) {
        event.target.classList.remove('needs-attention');
      }
      // Attempt to move to the next prompt if all required fields are filled
      showNextPrompt(nextPromptId);
    }
  });


//Next Button Function for the next section
    function nextPrompt() {
        const currentPrompt = document.querySelector('.prompt:nth-child(' + currentPromptIndex + ')');
        const inputs = currentPrompt.querySelectorAll('input[type="text"], input[type="number"], input[type="radio"]:checked, textarea,input[type="tel"],input[type="select"],input[type="range"]');

        // Check if any field is empty
        let emptyFields = false;
        inputs.forEach(input => {
            if (!input.value.trim()) {
                emptyFields = true;
                return;
            }
        });

        if (emptyFields) {
            alert('Please fill in all fields.');
            return;
        }

        // Store form data
        inputs.forEach(input => {
            if (input.type === 'radio') {
                if (input.checked) {
                    formData[input.name] = input.value;
                }
            } else {
                formData[input.id] = input.value;
            }
        });

        displayFormData();
        
        currentPrompt.style.display = 'none';
        currentPromptIndex++;
        const nextPrompt = document.querySelector('.prompt:nth-child(' + currentPromptIndex + ')');
        if (nextPrompt) {
            nextPrompt.style.display = 'block';
        } else {
            alert('All prompts completed.');
        }

        updateProgressBar();
    }


//Skip Button Function
    function skipPrompt(nextPromptId) {
        try {
            // Hide all prompts
            var prompts = document.querySelectorAll('.prompt-box');
            prompts.forEach(function(prompt) {
                prompt.classList.add('hidden');
            });

            // Show the next prompt
            var nextPrompt = document.getElementById(nextPromptId);
            if (nextPrompt) {
                nextPrompt.classList.remove('hidden');
            } else {
                console.error('No element with the ID ' + nextPromptId + ' was found.');
            }

            // Adjust the container height
            adjustContainerHeight(); 
        } catch (error) {
            console.error('An error occurred in skipPrompt:', error);
        }
    }

//Preview Button Function
    function previewProfile() {
        const currentPrompt = document.querySelector('.prompt:nth-child(' + currentPromptIndex + ')');
        const inputs = currentPrompt.querySelectorAll('input[type="text"], input[type="number"], input[type="radio"]:checked, textarea,input[type="tel"]');
        
        // Store form data
        inputs.forEach(input => {
            if (input.type === 'radio') {
                if (input.checked) {
                    formData[input.name] = input.value;
                }
            } else {
                formData[input.id] = input.value;
            }
        });

        displayFormData();
    }


// provious button funtion
  function showPreviousPrompt(currentPromptId) {
    // and each prompt has an 'id' and 'element' properties
    const prompts = [
        { id: 'promptFirstName', element: document.getElementById('promptFirstName') },
        { id: 'promptTask1', element: document.getElementById('promptTask1')},
        { id: 'promptPassion', element: document.getElementById('promptPassion')},
        { id: 'promptAvailability', element: document.getElementById('promptAvailability') },
        { id: 'promptPhone', element: document.getElementById('promptPhone') }
      ];
      
    // Find the prompt with the given ID
    const prompt = prompts.find(p => p.id === currentPromptId);
  
    // Make the prompt visible
    if (prompt && prompt.element) {
      prompt.element.style.display = 'block'; // This will make the element visible if it was hidden
      console.log('Showing prompt:', prompt);
    } else {
      console.log('Prompt not found or element not defined');
    }
  }


//Submit Button Function
function submitProfile() {
    const progressBar = document.getElementById('progress');
    progressBar.style.width = '100%';
    alert('Profile submitted successfully!');
    document.getElementById('prompt6').style.display = 'none';
    document.getElementById('prompt7').style.display = 'block';
}


//Display function for the entered data
function displayFormData() {
    let formDetails = '';
    for (const [key, value] of Object.entries(formData)) {
        formDetails += `${key}  : ${value}\n`;
    }
    alert('Form details:\n' + formDetails);
}

//Funtion to update the Progress Bar
function updateProgressBar() {
    const progressPercentage = Math.ceil((currentPromptIndex / totalPrompts) * 100);
    const progressBar = document.getElementById('progress');
    progressBar.style.width = progressPercentage + '%';
}


// adjusting the propt-box size according to the question's size
    function adjustContainerHeight() {
        var content = document.getElementById('prompt'); 
        var container = document.getElementById('container'); 
        container.style.height = content.scrollHeight + 'px';
    }

    adjustContainerHeight();


