const navlinks = document.querySelectorAll('.navlink');
const pathname = window.location.pathname;

navlinks.forEach(navlink => {
    if (navlink.href.includes(pathname)) {
        navlink.classList.add('active');
    }
})


document.addEventListener("DOMContentLoaded", function() {
    // Add class to profile container to trigger transition
    document.querySelector(".profile-container").classList.add("show");
});
