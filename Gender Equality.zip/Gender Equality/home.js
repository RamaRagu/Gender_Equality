document.addEventListener("DOMContentLoaded", function() {
    var slides = document.querySelectorAll('.slide');
    var textOverlays = document.querySelectorAll('.text-overlay');
    var radioButtons = document.querySelectorAll('.navigation-buttons input[type="radio"]');
    var currentSlide = 0;
    var autoSlideInterval;

    // Function to show slide and text overlay
    function showSlide(index) {
        slides.forEach((slide) => {
            slide.classList.remove('active');
        });
        textOverlays.forEach((overlay) => {
            overlay.style.opacity = '0';
        });
        slides[index].classList.add('active');
        textOverlays[index].style.opacity = '1';
        radioButtons[index].checked = true; // Update the checked state of the corresponding radio button
        currentSlide = index;
    }

    // Function to switch to the next slide
    function nextSlide() {
        var nextIndex = (currentSlide + 1) % slides.length;
        showSlide(nextIndex);
    }

    // Start the automatic slide transition
    function startAutoSlide() {
        autoSlideInterval = setInterval(nextSlide, 10000); 
    }

    // Show the first slide and start the interval
    showSlide(0);
    startAutoSlide();

    // Manual navigation with radio buttons
    radioButtons.forEach((radio, index) => {
        radio.addEventListener('change', () => {
            clearInterval(autoSlideInterval); // Stop auto sliding when manually navigating
            showSlide(index); // Show the corresponding slide
            startAutoSlide(); // Restart auto sliding after manual navigation
        });
    });
});
  
// Function to check if an element is in the viewport
function isElementInViewport(element) {
    // Get the bounding rectangle of the element
    const rect = element.getBoundingClientRect();
    // Check if all sides of the rectangle are within the viewport
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

// Function to animate counters when they come into view
function animateCounters() {
    // Get all elements with the class 'counter'
    const counters = document.querySelectorAll('.counter');
    
    // Iterate over each counter
    counters.forEach((counter) => {
        // Check if the counter is in the viewport
        if (isElementInViewport(counter)) {
            // If it's in the viewport, animate the counter
            animateCounter(counter);
        }
    });
}

// Function to animate a single counter
function animateCounter(counter) {
    // Get the target value to count to from the data attribute 'data-target'
    const target = counter.querySelector('.count').getAttribute('data-target');
    // Check if the target value represents a percentage
    const isPercentage = target.includes('%');
    // Convert the target value to a number
    const targetValue = isPercentage ? parseFloat(target) : parseInt(target, 10);
    // Set the speed of the animation
    const speed = 250;
    // Calculate the increment based on the speed and target value
    const inc = (targetValue / speed) || 1;
    
    // Function to update the counter value
    function update() {
        // Get the element displaying the count
        const countElement = counter.querySelector('.count');
        // Get the current count value
        const count = parseFloat(countElement.innerText) || 0;

        // If the current count is less than the target value, increment the count and update the display
        if (count < targetValue) {
            countElement.innerText = isPercentage
                ? `${Math.min(count + inc, targetValue).toFixed(2)}%`
                : Math.min(Math.floor(count + inc), targetValue);
            // Call the update function recursively after a short delay
            setTimeout(update, 15);
        }
    }

    // Call the update function to start the animation
    update();
}

// Add event listener to the scroll event to trigger counter animations
window.addEventListener('scroll', animateCounters);

// Trigger counter animations when the page loads
animateCounters();
