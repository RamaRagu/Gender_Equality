// Function to toggle the visibility of the feedback section
function toggleFeedbackSection(show) {
  const feedbackSection = document.getElementById('feedbackSection');
  feedbackSection.style.display = show ? 'block' : 'none';
}

// Function to validate email format
function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// Function to display error messages
function displayError(fieldId, message) {
  var errorContainer = document.getElementById(fieldId + '-error');
  errorContainer.innerHTML = message;
}

// Function to clear error messages and styles
function clearError(fieldId) {
  var errorContainer = document.getElementById(fieldId + '-error');
  errorContainer.innerHTML = '';

  var field = document.getElementById(fieldId);
  field.classList.remove('invalid-field');
}

// Add event listener to the preview button to trigger form validation
document.getElementById('preview').addEventListener('click', function(event) {
  event.preventDefault(); // Prevent the default form submission behavior
  validateForm(); // Call the validateForm function
});

// Function to validate the form inputs
function validateForm() {
  var name = document.getElementById('name').value;
  var email = document.getElementById('email').value;
  var mobile = document.getElementById('mobile').value;
  var userFriendlyYes = document.getElementById('userFriendlyYes');
  var userFriendlyNo = document.getElementById('userFriendlyNo');
  var recommendYes = document.getElementById('recommendYes');
  var recommendNo = document.getElementById('recommendNo');
  var isValid = true;

  // Validate name
  if (!name) {
      displayError('name', 'Please enter your name.');
      isValid = false;
  }

  // Validate email
  if (!validateEmail(email)) {
      displayError('email', 'Please enter a valid email address.');
      isValid = false;
  }

  if (!mobile) {
      displayError('mobile', 'Please enter mobile number.');
      isValid = false;
  }

  // Validate user-friendly
  if (!(userFriendlyYes.checked || userFriendlyNo.checked)) {
      displayError('userFriendly', 'Please select whether the website is user-friendly.');
      isValid = false;
  }

  // Validate recommendation
  if (!(recommendYes.checked || recommendNo.checked)) {
      displayError('recommend', 'Please select whether you would recommend our services.');
      isValid = false;
  }

  // If all inputs are valid, show the preview
  if (isValid) {
      showPreview();
  }
}

// Function to show the preview and handle confirm/edit actions
function showPreview() {
  // Gather form data and display it in the preview container
  var name = document.getElementById('name').value;
  var email = document.getElementById('email').value;
  var mobile = document.getElementById('mobile').value;
  var firstTime = (document.querySelector('input[name="firstTime"]:checked') ?? {}).value;
  var userFriendly = document.querySelector('input[name="userFriendly"]:checked').value;
  var suggestions = document.getElementById('suggestions').value;
  var rating = (document.querySelector('input[name="star"]:checked') ?? {}).value;
  var recommend = document.querySelector('input[name="recommend"]:checked').value;
  var updates = document.getElementById('updatesSelect')?.value ?? null;
  var QnA = document.getElementById('QnA').value;

  // Update the content of the preview-container div with the form data
  document.getElementById('preview-name').textContent = name;
  document.getElementById('preview-email').textContent = email;
  document.getElementById('preview-mobile').textContent = mobile;
  document.getElementById('preview-firstTime').textContent = firstTime;
  document.getElementById('preview-userFriendly').textContent = userFriendly;
  document.getElementById('preview-suggestions').textContent = suggestions;
  document.getElementById('preview-rating').textContent = rating;
  document.getElementById('preview-recommend').textContent = recommend;
  document.getElementById('preview-updates').textContent = updates;
  document.getElementById('preview-QnA').textContent = QnA;

  var formContainer = document.getElementById('feedbackForm'); // Use the form ID
  var previewContainer = document.getElementById('preview-container');

  if (formContainer && previewContainer) {
    formContainer.style.display = 'none';
    previewContainer.style.display = 'block';
  }
}

function hidePreview() {
  document.getElementById('preview-container').style.display = 'none';
  document.getElementById('feedbackForm').style.display = 'block';
}

// Function to handle the confirm action
function confirmFeedback() {
  // Gather form data
  var name = document.getElementById('name').value;
  var email = document.getElementById('email').value;
  var mobile = document.getElementById('mobile').value;
  var firstTime = (document.querySelector('input[name="firstTime"]:checked') ?? {}).value;
  var userFriendly = document.querySelector('input[name="userFriendly"]:checked').value;
  var suggestions = document.getElementById('suggestions').value;
  var rating = (document.querySelector('input[name="star"]:checked') ?? {}).value;
  var recommend = document.querySelector('input[name="recommend"]:checked').value;
  var updates = document.getElementById('updatesSelect')?.value ?? null;
  var QnA = document.getElementById('QnA').value;

  // Construct the email body
  var emailBody = 'Feedback Details:\n\n';
  emailBody += 'Name: ' + name + '\n';
  emailBody += 'Email: ' + email + '\n';
  emailBody += 'Mobile: ' + mobile + '\n';
  emailBody += 'First Time Visit: ' + firstTime + '\n';
  emailBody += 'User Friendly: ' + userFriendly + '\n';
  emailBody += 'Suggestions: ' + suggestions + '\n';
  emailBody += 'Rating: ' + rating + '\n';
  emailBody += 'Recommend: ' + recommend + '\n';
  emailBody += 'Updates: ' + updates + '\n';
  emailBody += 'QnA: ' + QnA + '\n';

  // Open the default email client with the email body
  window.location.href = 'mailto:subajanani@gmail.com?subject=Feedback&body=' + encodeURIComponent(emailBody);

  // Display confirmation message after the form is reset
  setTimeout(function () {
    alert('Thank you for your feedback! Your comment has been received.');
    location.reload();
    window.scrollTo(0, 0);
  }, 15000); 
}

function editFeedback() {
  // Allow the user to edit the feedback
  document.getElementById('preview-container').style.display = 'none';
  document.getElementById('feedbackForm').style.display = 'block';
}