
function cancelForm() {
    // Reset form inputs
    document.getElementById('checkout-form').reset();
    // Clear order summary content
    document.getElementById('order-summary-content').innerHTML = '';
}
document.addEventListener('DOMContentLoaded', function() {
    // Retrieve items from session storage
    const savedItems = JSON.parse(sessionStorage.getItem('cartItems'));

    if (savedItems && savedItems.length > 0) {
        // Display saved items in the order summary textarea
        const orderSummaryContent = document.getElementById('order-summary-content');
        let orderSummaryText = '';
        savedItems.forEach(item => {
            orderSummaryText += `${item.title} - ${item.price}\n`;
        });
        orderSummaryContent.value = orderSummaryText;
    } else {
        // No items found in session storage
        const orderSummaryContent = document.getElementById('order-summary-content');
        orderSummaryContent.value = 'No items found in the cart.';
    }
});
