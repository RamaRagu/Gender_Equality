// Select all elements with the class 'navlink'
const navlinks = document.querySelectorAll('.navlink');

// Get the current pathname of the window
const pathname = window.location.pathname;

// Loop through each navigation link
navlinks.forEach(navlink => {
    // Check if the href attribute of the navigation link includes the current pathname
    if (navlink.href.includes(pathname)) {
        // If the condition is true, add the 'active' class to the navigation link
        navlink.classList.add('active');
    }
});
